export { default as UploadAvatar } from './UploadAvatar';
export { default as UploadSingleFile } from './UploadSingleFile';
