// import { render } from '@testing-library/react';
// import { BrowserRouter } from 'react-router-dom';

// import App from './App';

// // eslint-disable-next-line no-undef
// test('renders the app', () => {
//   render(
//     <BrowserRouter>
//       <App />
//     </BrowserRouter>
//   );
// });
