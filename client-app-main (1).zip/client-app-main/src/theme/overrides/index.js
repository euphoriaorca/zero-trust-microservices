//
import CssBaseline from './CssBaseline';
// ------------------------------------------------------------------//

export default function ComponentsOverrides(theme) {
  return Object.assign(CssBaseline(theme));
}
