export { default as SetPasswordForm } from './setNewPassword';
