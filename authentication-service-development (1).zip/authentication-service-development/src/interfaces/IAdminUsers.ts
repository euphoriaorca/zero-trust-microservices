export enum UserTypes {
  USER0 = 'USER0',
  USER = 'USER',
}
