export interface IAdminUser {
  userId: string;
  permissions: string[];
}
