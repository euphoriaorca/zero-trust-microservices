export interface IModelOptions {
  select?: string[];
  where: Object;
}
