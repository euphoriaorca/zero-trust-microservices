export const EXPIRY_OFFSET = 300000; // in ms

export const ErrorCodes = {
  INVALID_AUTH: 'INVALID_AUTH',
};
