export interface IConfigOptions {
  authUrl: string;
  serviceId: string;
  serviceToken: string;
  payload?: any;
}
