### Distinct Request handler
