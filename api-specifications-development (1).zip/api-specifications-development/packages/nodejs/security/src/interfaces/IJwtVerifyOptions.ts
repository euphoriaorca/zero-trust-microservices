export interface IJwtVerifyOptions {
  token: string;
  pubKey: any;
}
