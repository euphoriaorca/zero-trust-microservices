export const PERMS_APP_PREFIX = 'apps.';
export const PERMS_USER_PREFIX = 'users.';
export const PERMS_SERVICE_PREFIX = 'svcs.';

export const HEADER_TOKEN_NAME = 'x-auth-token';
